// skip.js – Intro, Rückblick und Abspann automatisch überspringen (Nutzerwunsch). Läuft wie speed.js in allen Rahmen
// der Crunchyroll-Seiten (Player-iframe). Nutzt nur den eigenen „… überspringen“-Knopf des Players: Taucht er auf,
// wartet skip.js 2 s und klickt ihn dann einmal; danach geht es 1,5 s zurück, damit man nicht mitten in die Szene
// springt (statt 90 s also 86,5 s). Pause, Spulen oder ein verschwundener Knopf brechen das Warten ab.
// Ein Abschnitt, in den man selbst hineinspringt oder zu dem man zurückspult, wird nicht übersprungen: Jede Folge
// merkt sich ihre schon erledigten Abschnitte (Art aus der Beschriftung und Zeitspanne).
// Keine Schnittstelle, kein Netzverkehr. Schalter: Einstellung autoSkip (ab Werk an).
(() => {
  const WHAT = /intro|opening|vorspann|recap|rückblick|zusammenfassung|credits|abspann|outro|ending/i;
  const VERB = /skip|überspring/i;
  const done = new WeakSet(); // schon geklickte Knöpfe (wieder frei, sobald sie verschwinden: Player nutzt evtl. einen Knopf für Intro und Abspann)
  let on = true, timer = 0;
  let seen = [], episode = "", lastUserSeek = 0, ownUntil = 0; // erledigte Abschnitte { kind, start, end, el } dieser Folge
  const hooked = new WeakSet();
  // Art des Abschnitts aus der Beschriftung (leer, wenn der Knopf nur „Überspringen“ heißt)
  const kindOf = (text) => /intro|opening|vorspann/i.test(text) ? "intro" : /recap|rückblick|zusammenfassung/i.test(text) ? "recap" : /credits|abspann|outro|ending/i.test(text) ? "outro" : "";
  // schon erledigt? gleiche Art oder Zeitpunkt innerhalb einer erledigten Spanne
  const handled = (kind, t) => seen.some((x) => (kind && x.kind === kind) || (t >= x.start - 3 && t <= x.end + 3));

  // Schalter lesen (Hauptschalter und autoSkip)
  const load = () => chrome.storage.sync.get({ active: true, autoSkip: true }, (s) => { on = s.active && s.autoSkip; arm(); });
  load();
  chrome.storage.onChanged.addListener((c, area) => { if (area === "sync" && (c.active || c.autoSkip)) load(); });

  // Prüfung alle 0,25 s, aber nur solange in diesem Rahmen ein Video läuft (der Knopf erscheint oft nur per Klassenwechsel)
  function arm() {
    clearInterval(timer);
    if (on) timer = setInterval(check, 250);
  }

  // Beschriftung eines Knopfs (aria-label, title, Text)
  const label = (el) => [el.getAttribute("aria-label"), el.getAttribute("title"), el.textContent].filter(Boolean).join(" ").replace(/\s+/g, " ").trim();
  // sichtbar und groß genug?
  const visible = (el) => {
    const r = el.getBoundingClientRect();
    if (r.width < 20 || r.height < 12) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== "hidden" && cs.display !== "none" && +cs.opacity > 0.05;
  };

  // Überspringen-Knopf suchen; gefunden -> sofort einmal klicken (nur während das Video läuft)
  function check() {
    const video = document.querySelector("video");
    if (video) watch(video);
    if (!video || video.paused || video.ended) return;
    for (const x of seen) if (x.open && x.el && !x.el.isConnected) { x.end = video.currentTime; x.open = false; }
    const list = document.querySelectorAll('[data-testid*="skip" i], button, [role="button"]');
    for (const el of list) {
      if (done.has(el)) {
        if (!visible(el)) { done.delete(el); for (const x of seen) if (x.el === el && x.open) { x.end = video.currentTime; x.open = false; } }
        continue;
      }
      if (el.closest("[data-crlf-speed]")) continue;
      const text = label(el);
      if (text.length > 60) continue; // ganze Leisten/Menüs, nicht ein Knopf
      const testid = (el.getAttribute("data-testid") || "").toLowerCase();
      if (!(testid.includes("skip") || (VERB.test(text) && WHAT.test(text)))) continue;
      if (!visible(el)) continue;
      done.add(el);
      const kind = kindOf(text || testid), t = video.currentTime;
      // selbst hineingesprungen (Knopf kam direkt nach eigenem Spulen) oder schon erledigt (zurückgespult): stehen lassen
      if (Date.now() - lastUserSeek < 2500 || handled(kind, t)) { remember(kind, t, el); return; }
      // klicken; das Ende des Abschnitts ist dort, wo der Player hinspringt. Kein eigenes Spulen.
      const at = Date.now(), entry = { kind, start: t, end: t + 600, open: true };
      seen.push(entry);
      ownUntil = at + 4000; // der Sprung des Players zählt nicht als eigenes Spulen
      video.addEventListener("seeked", () => { if (Date.now() - at < 4000) { entry.end = video.currentTime; entry.open = false; } }, { once: true });
      press(el);
      return;
    }
  }

  // Abschnitt als erledigt merken (Ende folgt, wenn der Knopf verschwindet)
  function remember(kind, t, el) { seen.push({ kind, start: t, end: t + 600, el, open: true }); }

  // eigenes Spulen bemerken; neue Folge (andere Quelle oder Seite) = Liste leeren
  function watch(video) {
    const key = location.href + "|" + (video.currentSrc || "");
    if (key !== episode) { episode = key; seen = []; }
    if (hooked.has(video)) return;
    hooked.add(video);
    video.addEventListener("seeking", () => { if (Date.now() > ownUntil) lastUserSeek = Date.now(); });
  }

  // Klick auslösen. Der Treffer kann ein SVG o. Ä. ohne .click() sein (data-testid am Symbol): dann den umgebenden
  // Knopf nehmen bzw. die Mausereignisse selbst schicken, wie ein echter Klick sie liefert
  function press(el) {
    const btn = el.closest("button, [role=button], a") || el;
    if (typeof btn.click === "function") { btn.click(); return; }
    const r = btn.getBoundingClientRect(), at = { bubbles: true, cancelable: true, composed: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    for (const t of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) btn.dispatchEvent(new (t.startsWith("pointer") ? PointerEvent : MouseEvent)(t, at));
  }
})();
