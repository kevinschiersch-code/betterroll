// i18n.js – Sprache der Bedienoberfläche (Einstellung „uiLang“: "de" ab Werk oder "en").
// Alle eigenen Texte stehen im Code auf Deutsch und laufen durch T("…"); bei Englisch kommt die Übersetzung aus CRLF_EN
// (fehlt ein Eintrag, bleibt der deutsche Text). Platzhalter {0}, {1} … werden durch die weiteren Argumente ersetzt.
// Nicht übersetzt werden Muster, die Texte der Crunchyroll-Seite erkennen (die müssen Deutsch und Englisch treffen).
// Im Kalender einmal mit theme.js (document_start) geladen; content.js & Co. teilen sich denselben Bereich.
// var statt let/const, damit ein versehentlich doppeltes Laden keinen Fehler „bereits deklariert“ auslöst.

var crlfLang = typeof crlfLang === "string" ? crlfLang : "de";

var CRLF_EN = {
  // Popup: Kopf und Status
  "Add-on und Kalender neu laden": "Reload add-on and calendar",
  "Popup hell/dunkel umschalten": "Toggle popup light/dark",
  "Add-on an/aus": "Add-on on/off",
  "Add-on aktiv": "Add-on active",
  "Aus: Kalender wie im Original": "Off: calendar as original",
  "Öffne den Simulcast-Kalender": "Open the simulcast calendar",
  "Kalender neu laden, damit der Filter greift": "Reload the calendar to apply the filter",
  "{0} Einträge ausgeblendet": "{0} entries hidden",
  "v{0} bereit: oben auf ↻ klicken": "v{0} ready: click ↻ at the top",
  "v{0} verfügbar: oben auf ↻ klicken": "v{0} available: click ↻ at the top",
  "Update auf v{0} laden": "Download update v{0}",
  "v{0} wird geladen …": "Downloading v{0} …",
  "Aktualisiert auf v{0}, startet neu …": "Updated to v{0}, restarting …",
  "Update fehlgeschlagen: {0}": "Update failed: {0}",
  "Kopieren nicht möglich": "Copying not possible",
  // Popup: Fassung
  "Fassung": "Version",
  "Sprache": "Language",
  "Welche Fassung zeigen": "Which version to show",
  "bevorzugt": "preferred",
  "OmU": "Sub",
  "Alle": "All",
  "ungefiltert": "unfiltered",
  "Pro Anime eine Karte: {0}, sonst OmU.": "One card per anime: {0}, else Sub.",
  "Pro Anime eine Karte: OmU, sonst {0}.": "One card per anime: Sub, else {0}.",
  "Alle Fassungen und Sprachen wie auf der Seite.": "All versions and languages as on the page.",
  // Popup: Kalender
  "Kalender": "Calendar",
  "Kopfbereich ausblenden": "Hide header area",
  "Design": "Design",
  "Design des Kalenders": "Calendar design",
  "Hell": "Light",
  "Dunkel": "Dark",
  "Raster": "Grid",
  "Haus": "House",
  "Baum": "Tree",
  "Altstadt": "Old town",
  "Wechselnd": "Rotating",
  "alle 45 s": "every 45 s",
  "Motiv wechselt alle 45 Sekunden": "Scene changes every 45 seconds",
  "Motiv des Hintergrundvideos": "Background video scene",
  "Bild": "Image",
  "Bild-URL einfügen · ideal {0} px": "Paste image URL · ideal {0} px",
  "Adresse des Hintergrundbilds": "Background image address",
  "Bild vom PC wählen": "Choose image from PC",
  "Bild entfernen": "Remove image",
  "Ideal für deinen Bildschirm: {0} px (Querformat)": "Ideal for your screen: {0} px (landscape)",
  "Bild {0} px ist kleiner als ideal ({1}), wirkt evtl. unscharf": "Image {0} px is smaller than ideal ({1}), may look blurry",
  "Bild {0} px · ideal {1}": "Image {0} px · ideal {1}",
  "Bild nicht geladen: {0}": "Image not loaded: {0}",
  "Keine gültige Adresse": "Not a valid address",
  "Kein Bild": "not an image",
  "Zugriff auf {0} nicht erlaubt": "Access to {0} not allowed",
  "Bild wird geladen …": "Loading image …",
  "Bilder": "Images",
  "Vorschaubilder der Karten": "Card thumbnails",
  "Vorschaubild bei jedem Anime": "Thumbnail for every anime",
  "Vorschaubild nur bei hervorgehobenen (★)": "Thumbnail only for highlighted (★)",
  "Keine Vorschaubilder": "No thumbnails",
  "★ Favoriten": "★ Favorites",
  "Keine": "None",
  "Größe": "Size",
  "Größe der Vorschaubilder": "Thumbnail size",
  // Popup: Erweitert
  "Erweitert": "Advanced",
  "Knöpfe": "Buttons",
  "Ausblenden": "Hide",
  "Kommentare": "Comments",
  "Hervorheben-Knopf": "Highlight button",
  "Ausblenden-Knopf": "Hide button",
  "Kommentare-Knopf (AniList)": "Comments button (AniList)",
  "Sprache und Staffel als Abzeichen": "Language and season as badges",
  "Titel aufräumen": "Tidy titles",
  "Wiedergabe": "Playback",
  "Geschwindigkeit": "Speed",
  "Tempo im Menü „1x“, Tasten − / +": "Speed in the “1x” menu, keys − / +",
  "Auto-Skip": "Auto-skip",
  "Intro, Rückblick und Abspann überspringen": "Skip intro, recap and credits",
  "Einblendungen": "Overlays",
  "Automatisch schließen": "Close automatically",
  "Bildschirmfüllende Hinweise, z. B. nach der letzten Folge": "Full-screen notices, e.g. after the last episode",
  "★ Favoriten nach oben": "★ Favorites to top",
  "Aus: Favoriten bleiben hervorgehoben, aber an ihrer Stelle im Kalender": "Off: favorites stay highlighted but keep their place in the calendar",
  "Datum": "Date",
  "Datum und Uhrzeit": "Date and time",
  // Sprachnamen (Zusätze in Klammern)
  "Deutsch": "German",
  "中文 (Chinesisch)": "中文 (Chinese)",
  "한국어 (Koreanisch)": "한국어 (Korean)",
  "日本語 (Japanisch)": "日本語 (Japanese)",
  // Kalenderkarten (content.js)
  "Hervorheben": "Highlight",
  "Ausblenden (ausgrauen, nach unten)": "Hide (grey out, move down)",
  "Kommentare zur Folge": "Episode comments",
  "Fortschritt {0} %": "Progress {0} %",
  "Sprachfassung": "Language version",
  "Auch verfügbar: {0}": "Also available: {0}",
  "ST": "S",
  "T": "P",
  "Staffel {0}": "Season {0}",
  ", Teil {0}": ", part {0}",
  // Kommentar-Panel (comments.js)
  "MyAnimeList-Abruf fehlgeschlagen. Bitte das Add-on mit ↻ neu laden.": "MyAnimeList request failed. Please reload the add-on with ↻.",
  "MyAnimeList meldet zu viele Anfragen. Bitte kurz warten und erneut öffnen.": "MyAnimeList reports too many requests. Please wait a moment and open again.",
  "MyAnimeList (Jikan) ist gerade überlastet oder nicht erreichbar (Fehler {0}).": "MyAnimeList (Jikan) is overloaded or unreachable right now (error {0}).",
  "MyAnimeList-Abruf fehlgeschlagen (Fehler {0}).": "MyAnimeList request failed (error {0}).",
  "MyAnimeList nicht erreichbar ({0}).": "MyAnimeList unreachable ({0}).",
  "keine Verbindung": "no connection",
  "Zeitüberschreitung": "timeout",
  "Folgen {0}–{1}": "Episodes {0}–{1}",
  "Folge {0}": "Episode {0}",
  "Diskussion": "Discussion",
  "Schließen (Esc)": "Close (Esc)",
  "Suche bei AniList …": "Searching AniList …",
  "AniList: nichts gefunden": "AniList: nothing found",
  "AniList klappt nicht, versuche MyAnimeList …": "AniList failed, trying MyAnimeList …",
  "MyAnimeList: nichts gefunden": "MyAnimeList: nothing found",
  "Keine Kommentar-Quelle erreichbar.": "No comment source reachable.",
  "Abruf fehlgeschlagen, bitte das Add-on mit ↻ neu laden": "Request failed, please reload the add-on with ↻",
  "Fehler in der Antwort": "error in the response",
  "zu viele Anfragen, bitte kurz warten": "too many requests, please wait a moment",
  "Fehler {0}": "error {0}",
  "Anime bei {0}": "Anime on {0}",
  "Lade Diskussionen …": "Loading discussions …",
  "Noch keine Kommentare.": "No comments yet.",
  "Auf AniList mitdiskutieren ↗": "Join the discussion on AniList ↗",
  "Überblick über die Staffel:": "Season overview:",
  "Durchschnittsbewertung": "Average score",
  "{0} Mitglieder auf AniList": "{0} members on AniList",
  "{0}/100 · Rezension von {1}": "{0}/100 · review by {1}",
  "Neueste Diskussionen:": "Latest discussions:",
  "Auf AniList ansehen ↗": "View on AniList ↗",
  "Keine Diskussion zu Folge {0}": "No discussion for episode {0}",
  ", neueste: Folge {0}": ", latest: episode {0}",
  "Folge der Karte unbekannt": "Episode of the card unknown",
  ", neueste Diskussion: Folge {0}": ", latest discussion: episode {0}",
  "Zu diesem Anime gibt es noch keine Folgen-Threads.": "There are no episode threads for this anime yet.",
  "Neueste Folgen-Threads (Nummerierung kann abweichen):": "Latest episode threads (numbering may differ):",
  "Auf MyAnimeList mitschreiben ↗": "Join the discussion on MyAnimeList ↗",
  "{0} Kommentare": "{0} comments",
  " · zuletzt {0}, {1}": " · last {0}, {1}",
  "[Spoiler: {0}]": "[Spoiler: {0}]",
  "[Bild]": "[Image]",
  // Vorschau und Bewertungen (theme.js), weitere Popup-Texte
  "Kalender hell/dunkel umschalten": "Toggle calendar light/dark",
  "Vorschau: {0}": "Preview: {0}",
  "Aktuell": "Current",
  "Nächste Staffel": "Next season",
  "Geschwindigkeit im Player": "Speed control in the player",
  "Player": "Player",
  "Heute": "Today",
  "Top 10 der Season": "Top 10 of the season",
  "AniList-Community": "AniList community",
  "Beste Bewertung": "Top rated",
  "Beliebteste": "Most popular",
  "Lädt …": "Loading …",
  "AniList nicht erreichbar ({0}).": "AniList not reachable ({0}).",
  "Für diese Season gibt es noch keine Liste.": "No list for this season yet.",
  "Im Kalender zeigen": "Show in calendar",
  "noch keine Note": "no score yet",
  "{0} Mitglieder": "{0} members",
  "★ Favorit": "★ Favorite",
  "im Kalender": "in calendar",
  "Zu heute springen": "Jump to today",
  "Wieder alle Anime zeigen": "Show all anime again",
  "Nur Favoriten (★) zeigen": "Show favorites (★) only",
  "Keine Favoriten an diesem Tag": "No favorites on this day",
  "Nur Favoriten (★) zeigen – noch keine markiert": "Show favorites (★) only – none marked yet",
  "Intro, Rückblick und Abspann automatisch überspringen": "Skip intro, recap and credits automatically",
  "Bildschirmfüllende Einblendungen (z. B. nach der letzten Folge) automatisch schließen": "Automatically close full-screen overlays (e.g. after the last episode)",
  "Zur Serie": "Go to series",
  "Abspielen": "Play",
  "Schließen": "Close",
  "📰 News ({0})": "📰 News ({0})",
  "Quelle: ": "Source: ",
  "Start": "Start",
  "ungefährer Start": "approx. start",
  "{0} Bewertungen": "{0} ratings",
  "{0} Mio.": "{0}M",
  "{0} Tsd.": "{0}K",
  "wird geladen …": "loading …",
  "noch keine Bewertung": "no rating yet",
  "keine Daten": "no data",
  "bestbewertet": "top rated",
  "beliebteste": "most popular",
  "Frühling": "Spring",
  "Sommer": "Summer",
  "Herbst": "Fall"
};

// Text in der gewählten Sprache; T("Folge {0}", 5) -> "Folge 5" bzw. "Episode 5"
function T(de, ...args) {
  let s = crlfLang === "en" && Object.prototype.hasOwnProperty.call(CRLF_EN, de) ? CRLF_EN[de] : de;
  if (args.length) s = s.replace(/\{(\d+)\}/g, (m, i) => (args[+i] !== undefined ? String(args[+i]) : m));
  return s;
}

// Zahlen und Datumsangaben passend zur Sprache
function crlfLocale() { return crlfLang === "en" ? "en-US" : "de-DE"; }

// gespeicherte Sprache laden; crlfLangReady ist erfüllt, sobald crlfLang feststeht (das Popup wartet darauf)
var crlfLangReady = new Promise((ok) => {
  try {
    chrome.storage.sync.get({ uiLang: "de" }, (s) => {
      crlfLang = s && s.uiLang === "en" ? "en" : "de";
      ok(crlfLang);
    });
  } catch (e) { ok(crlfLang); }
});

// Staffel-Abzeichen „ST 1 | T 2“ (englisch „S 1 | P 2“) ohne innerHTML aufbauen
function crlfSeasonBadge(el, n, part) {
  const small = (t) => { const e = document.createElement("small"); e.textContent = t; return e; };
  el.replaceChildren(small(T("ST")), String(n));
  if (part) { const sep = document.createElement("i"); sep.className = "crlf-sep"; el.append(sep, small(T("T")), String(part)); }
}
