@echo off
rem Richtet automatische Updates fuer BetterRoll ein (nur fuer diesen Windows-Benutzer, sendet keine Daten).
powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0setup-updates.ps1"
