@echo off
rem Schaltet die automatischen Updates fuer BetterRoll wieder aus.
powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0setup-updates.ps1" -Remove
