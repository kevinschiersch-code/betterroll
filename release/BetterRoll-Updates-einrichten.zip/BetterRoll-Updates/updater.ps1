﻿# updater.ps1 – automatische Updates für Chrome/Edge/Brave (entpackt installiertes Add-on)
# Läuft unsichtbar (über updater.vbs) bei jeder Windows-Anmeldung und stündlich (Aufgabenplanung).
# Fragt nur die öffentliche Datei latest.json ab, lädt bei neuerer Version das Paket herunter, prüft dessen SHA-256
# und tauscht die Dateien im Add-on-Ordner aus. Das Add-on bemerkt die neue Version selbst und lädt sich neu.
# Es werden keine Daten gesendet, es braucht keine Anmeldung und keine Zugangsdaten.
#
# Add-on-Ordner: aus config.json ({"extension": "<Pfad>"}, angelegt von setup-updates.ps1), sonst der Ordner
# des Installers (%LOCALAPPDATA%\BetterRoll\extension). Ausgetauscht wird nur ein Ordner, dessen manifest.json
# wirklich zu BetterRoll gehört.
$ErrorActionPreference = 'Stop'
$Base = 'https://raw.githubusercontent.com/kevinschiersch-code/betterroll/main/release'
$Root = Join-Path $env:LOCALAPPDATA 'BetterRoll'
$Log  = Join-Path $Root 'update.log'
$Last = Join-Path $Root 'last-check.txt'

# ===== 1. Hilfen =====

function Write-Log($msg) {
  $line = "{0:yyyy-MM-dd HH:mm}  {1}" -f (Get-Date), $msg
  Add-Content -Path $Log -Value $line -Encoding UTF8
  # Protokoll klein halten
  $lines = @(Get-Content $Log -Encoding UTF8)
  if ($lines.Count -gt 200) { $lines | Select-Object -Last 100 | Set-Content $Log -Encoding UTF8 }
}

# letzte Prüfung festhalten (eine Zeile, wird jedes Mal überschrieben)
function Write-Last($msg) { Set-Content -Path $Last -Value ("{0:yyyy-MM-dd HH:mm}  {1}" -f (Get-Date), $msg) -Encoding UTF8 }

function Test-Newer([string]$a, [string]$b) {
  try { return ([version]$a) -gt ([version]$b) } catch { return $false }
}

# Add-on-Ordner bestimmen
function Get-ExtensionDir {
  $cfg = Join-Path $Root 'config.json'
  if (Test-Path $cfg) {
    $c = Get-Content $cfg -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($c.extension) { return [string]$c.extension }
  }
  return (Join-Path $Root 'extension')
}

# Sicherheitsnetz: nur einen BetterRoll-Ordner anfassen, nie Laufwerk, Benutzerordner, Downloads, Desktop usw.
function Test-OurFolder([string]$dir) {
  $full = [IO.Path]::GetFullPath($dir).TrimEnd('\', '/')
  $forbidden = @($env:USERPROFILE, $env:LOCALAPPDATA, $env:APPDATA, $env:SystemRoot, $env:ProgramFiles, ${env:ProgramFiles(x86)},
    [Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('MyDocuments')) |
    Where-Object { $_ } | ForEach-Object { [IO.Path]::GetFullPath($_).TrimEnd('\', '/') }
  if ($env:USERPROFILE) { $forbidden += [IO.Path]::GetFullPath((Join-Path $env:USERPROFILE 'Downloads')).TrimEnd('\', '/') }
  if ($full.Length -le 3 -or $forbidden -contains $full) { return $false }
  $mf = Join-Path $full 'manifest.json'
  if (-not (Test-Path $mf)) { return $false }
  $m = Get-Content $mf -Raw -Encoding UTF8 | ConvertFrom-Json
  return ($m.manifest_version -eq 3 -and [string]$m.name -match '^(BetterRoll|Crunchyroll|Kalender)')
}

# ===== 2. Prüfen und austauschen =====

try {
  New-Item -ItemType Directory -Path $Root -Force | Out-Null
  $Ext = Get-ExtensionDir
  if (-not (Test-Path (Join-Path $Ext 'manifest.json'))) { Write-Last "kein Add-on-Ordner: $Ext"; exit 0 }
  if (-not (Test-OurFolder $Ext)) { throw "Ordner sieht nicht nach BetterRoll aus, wird nicht angefasst: $Ext" }
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  $current = (Get-Content (Join-Path $Ext 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json).version
  # ?t=… umgeht Zwischenspeicher unterwegs, damit eine neue Version schnell ankommt. Bewusst Invoke-WebRequest +
  # ConvertFrom-Json: GitHub liefert .json als text/plain, Invoke-RestMethod gäbe in Windows PowerShell 5 dann nur Text zurück
  $res = Invoke-WebRequest -Uri ("$Base/latest.json?t=" + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()) -UseBasicParsing -TimeoutSec 30 -Headers @{ 'Cache-Control' = 'no-cache' }
  $latest = $res.Content | ConvertFrom-Json
  if (-not (Test-Newer $latest.version $current)) { Write-Last "aktuell ($current)"; exit 0 }
  if ($latest.chrome -notmatch '^[A-Za-z0-9._-]+\.zip$' -or $latest.sha256 -notmatch '^[0-9a-fA-F]{64}$') { throw 'latest.json ungültig' }

  $tmp = Join-Path ([IO.Path]::GetTempPath()) ("betterroll-" + [guid]::NewGuid())
  New-Item -ItemType Directory -Path $tmp | Out-Null
  try {
    $zip = Join-Path $tmp 'update.zip'
    Invoke-WebRequest -Uri "$Base/$($latest.chrome)" -OutFile $zip -UseBasicParsing -TimeoutSec 120
    $hash = (Get-FileHash $zip -Algorithm SHA256).Hash
    if ($hash -ne $latest.sha256.ToUpper()) { throw "Prüfsumme passt nicht ($hash)" }
    $new = Join-Path $tmp 'extension'
    Expand-Archive -Path $zip -DestinationPath $new
    $newVersion = (Get-Content (Join-Path $new 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json).version
    if ($newVersion -ne $latest.version) { throw "Paket hat Version $newVersion statt $($latest.version)" }
    # Spracheinstellung des Installers behalten
    $lang = Join-Path $Ext 'lang.json'
    if (Test-Path $lang) { Copy-Item $lang (Join-Path $new 'lang.json') -Force }
    # erst alles Neue hineinkopieren (überschreibt), dann übrig gebliebene alte Dateien entfernen.
    # manifest.json kommt zuletzt, damit das Add-on die neue Version erst sieht, wenn alle Dateien da sind.
    Get-ChildItem $new -Force | Where-Object { $_.Name -ne 'manifest.json' } | Copy-Item -Destination $Ext -Recurse -Force
    $keep = @(Get-ChildItem $new -Force | ForEach-Object { $_.Name })
    Get-ChildItem $Ext -Force | Where-Object { $keep -notcontains $_.Name } | Remove-Item -Recurse -Force
    Copy-Item (Join-Path $new 'manifest.json') (Join-Path $Ext 'manifest.json') -Force
    Write-Log "aktualisiert: $current -> $newVersion ($Ext)"
    Write-Last "aktualisiert: $current -> $newVersion"
  } finally {
    Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
  }
} catch {
  Write-Log "Fehler: $($_.Exception.Message)"
  Write-Last "Fehler: $($_.Exception.Message)"
}
