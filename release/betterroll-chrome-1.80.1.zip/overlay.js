// overlay.js – läuft auf allen Crunchyroll-Seiten. Schließt bildschirmfüllende Einblendungen, die von selbst
// erscheinen (z. B. nach der letzten Folge), indem es ihren eigenen ✕-Knopf drückt (Nutzerwunsch; Popup → Erweitert →
// „Player“ ✕, Einstellung autoClose, ab Werk an). Vorsichtig, damit nichts Wichtiges zugeht:
//   - nur Ebenen, die den größten Teil des Fensters bedecken (fest stehend, über der Seite) und einen
//     Schließen-Knopf oben rechts haben
//   - nie mit Videoplayer, Eingabefeldern (Anmeldung, Suche) oder Cookie-Abfrage
//   - nie, wenn man kurz vorher selbst geklickt/getippt hat (dann hat man sie vermutlich selbst geöffnet, z. B. das Menü)
//   - je Ebene nur ein Versuch (geht sie davon nicht zu, bleibt sie offen)
// Gesucht wird nur an einigen Punkten des Fensters (elementFromPoint und Vorfahren), nicht im ganzen Dokument.
// Was geschlossen wurde, steht für „Fehler melden“ in storage.local „crClosedOverlays“ (die letzten 5, ohne Kontodaten).
(() => {
  let on = true, userAt = 0, timer = 0;
  const tried = new WeakSet(); // Ebenen, die schon einmal geschlossen werden sollten
  const CLOSE_RE = /^(close|schlie(ß|ss)en|dismiss|×|✕|✖|x)$|close|schlie(ß|ss)en|dismiss/i;
  chrome.storage.sync.get({ active: true, autoClose: true }, (s) => { on = s.active && s.autoClose; check(); });
  chrome.storage.onChanged.addListener((c, area) => {
    if (area !== "sync" || !(c.active || c.autoClose)) return;
    chrome.storage.sync.get({ active: true, autoClose: true }, (s) => { on = s.active && s.autoClose; });
  });
  for (const t of ["pointerdown", "keydown", "touchstart"]) addEventListener(t, () => { userAt = Date.now(); }, { capture: true, passive: true });

  // Schließen-Knopf der Ebene: Beschriftung/Titel nach „Schließen“, oder ein Kreuz, und er sitzt im oberen rechten Viertel
  function closeButton(layer, r) {
    for (const b of layer.querySelectorAll('button, [role="button"], a[href="#"], [aria-label]')) {
      const label = [b.getAttribute("aria-label"), b.getAttribute("title"), b.dataset && b.dataset.t, b.textContent].filter(Boolean).join(" ").trim();
      if (!label || label.length > 40 || !CLOSE_RE.test(label)) continue;
      const br = b.getBoundingClientRect();
      if (!br.width || !br.height) continue;
      if (br.left + br.width / 2 < r.left + r.width / 2 || br.top + br.height / 2 > r.top + r.height / 2) continue;
      return b;
    }
    return null;
  }

  // fest stehende Ebenen unter der Fenstermitte und vier weiteren Punkten (jeweils das Element und seine Vorfahren)
  function candidates(vw, vh) {
    const out = new Set();
    for (const [fx, fy] of [[0.5, 0.5], [0.3, 0.3], [0.7, 0.3], [0.3, 0.7], [0.7, 0.7]]) {
      for (let el = document.elementFromPoint(vw * fx, vh * fy); el && el !== document.body && el !== document.documentElement; el = el.parentElement) out.add(el);
    }
    return out;
  }

  // große Einblendung gefunden? Dann ihren ✕-Knopf drücken (je Ebene höchstens einmal)
  function check() {
    if (!on || !document.body || document.fullscreenElement) return;
    if (Date.now() - userAt < 1500) return; // selbst geöffnet
    const vw = innerWidth, vh = innerHeight;
    for (const el of candidates(vw, vh)) {
      if (tried.has(el) || el.closest('[class*="crlf-"], #crlf-theme-toggle, #crlf-tools')) continue;
      const cs = getComputedStyle(el);
      if (cs.position !== "fixed" || cs.display === "none" || cs.visibility === "hidden" || parseFloat(cs.opacity) < 0.1) continue;
      const r = el.getBoundingClientRect();
      if (r.width < vw * 0.6 || r.height < vh * 0.6) continue;
      if (el.querySelector('video, iframe, input:not([type="checkbox"]):not([type="radio"]):not([type="hidden"]), textarea, select')) { seen(el, "Video/Eingabe"); continue; }
      const id = `${el.id} ${el.className && el.className.baseVal !== undefined ? el.className.baseVal : el.className}`;
      if (/onetrust|consent|cookie|login|signin|sign-in|auth|search|player/i.test(id)) { seen(el, "Name"); continue; }
      const btn = closeButton(el, r);
      if (!btn) { seen(el, "kein ✕"); continue; }
      tried.add(el);
      el.style.setProperty("visibility", "hidden", "important"); // nicht erst aufblitzen lassen
      btn.click();
      setTimeout(() => { if (el.isConnected) el.style.removeProperty("visibility"); }, 1500); // ging nicht zu: wieder zeigen
      log(el);
      return;
    }
  }

  // große Ebene gesehen, aber absichtlich offen gelassen: für „Fehler melden“ merken (nur die letzte, je Ebene einmal)
  let lastSeen = null;
  function seen(el, reason) {
    if (lastSeen === el) return;
    lastSeen = el;
    const btns = [...el.querySelectorAll('button, [role="button"]')].slice(0, 6).map((b) => (b.getAttribute("aria-label") || b.textContent || "").trim().slice(0, 20)).join("|");
    chrome.storage.local.set({ crOverlaySeen: { t: Date.now(), reason, page: location.pathname.replace(/\/[A-Z0-9]{8,}(\/[^/]*)?/gi, "/…"),
      cls: String(el.className || "").slice(0, 80), text: (el.innerText || "").replace(/\s+/g, " ").trim().slice(0, 80), btns } }).catch(() => {});
  }

  // geschlossene Ebene für „Fehler melden“ merken (Seite ohne IDs, Klassen, Textanfang)
  async function log(el) {
    try {
      const { crClosedOverlays: list = [] } = await chrome.storage.local.get("crClosedOverlays");
      list.unshift({ t: Date.now(), page: location.pathname.replace(/\/[A-Z0-9]{8,}(\/[^/]*)?/gi, "/…"), cls: String(el.className || "").slice(0, 80),
        text: (el.innerText || "").replace(/\s+/g, " ").trim().slice(0, 80) });
      await chrome.storage.local.set({ crClosedOverlays: list.slice(0, 5) });
    } catch (e) {}
  }

  new MutationObserver(() => { clearTimeout(timer); timer = setTimeout(check, 60); })
    .observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["class", "style", "hidden", "open"] });
})();
