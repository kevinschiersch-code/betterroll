// i18n.js – Sprache der Bedienoberfläche (Einstellung „uiLang“: "de" ab Werk oder "en").
// Alle eigenen Texte stehen im Code auf Deutsch und laufen durch T("…"); bei Englisch kommt die Übersetzung aus CRLF_EN
// (fehlt ein Eintrag, bleibt der deutsche Text). Platzhalter {0}, {1} … werden durch die weiteren Argumente ersetzt.
// Nicht übersetzt werden Muster, die Texte der Crunchyroll-Seite erkennen (die müssen Deutsch und Englisch treffen).
// Im Kalender einmal mit theme.js (document_start) geladen; content.js & Co. teilen sich denselben Bereich.
// var statt let/const, damit ein versehentlich doppeltes Laden keinen Fehler „bereits deklariert“ auslöst.

var crlfLang = typeof crlfLang === "string" ? crlfLang : "de";

var CRLF_EN = {
  // Popup: Kopf und Status
  "Add-on und Kalender neu laden": "Reload add-on and calendar",
  "Popup hell/dunkel umschalten": "Toggle popup light/dark",
  "Add-on an/aus": "Add-on on/off",
  "Add-on aktiv": "Add-on active",
  "Aus: Kalender wie im Original": "Off: calendar as original",
  "Öffne den Simulcast-Kalender": "Open the simulcast calendar",
  "Kalender neu laden, damit der Filter greift": "Reload the calendar to apply the filter",
  "{0} Einträge ausgeblendet": "{0} entries hidden",
  "v{0} bereit: oben auf ↻ klicken": "v{0} ready: click ↻ at the top",
  "Kopieren nicht möglich": "Copying not possible",
  // Popup: Fassung
  "Fassung": "Version",
  "Sprache": "Language",
  "Welche Fassung zeigen": "Which version to show",
  "bevorzugt": "preferred",
  "OmU": "Sub",
  "Alle": "All",
  "ungefiltert": "unfiltered",
  "Pro Anime eine Karte: {0}, sonst OmU.": "One card per anime: {0}, else Sub.",
  "Pro Anime eine Karte: OmU, sonst {0}.": "One card per anime: Sub, else {0}.",
  "Alle Fassungen und Sprachen wie auf der Seite.": "All versions and languages as on the page.",
  // Popup: Kalender
  "Kalender": "Calendar",
  "Kopfbereich ausblenden": "Hide header area",
  "Design": "Design",
  "Design des Kalenders": "Calendar design",
  "Hell": "Light",
  "Dunkel": "Dark",
  "Raster": "Grid",
  "Bild": "Image",
  "Bild-URL einfügen · ideal {0} px": "Paste image URL · ideal {0} px",
  "Adresse des Hintergrundbilds": "Background image address",
  "Bild vom PC wählen": "Choose image from PC",
  "Bild entfernen": "Remove image",
  "Ideal für deinen Bildschirm: {0} px (Querformat)": "Ideal for your screen: {0} px (landscape)",
  "Bild {0} px ist kleiner als ideal ({1}), wirkt evtl. unscharf": "Image {0} px is smaller than ideal ({1}), may look blurry",
  "Bild {0} px · ideal {1}": "Image {0} px · ideal {1}",
  "Bild nicht geladen: {0}": "Image not loaded: {0}",
  "Keine gültige Adresse": "Not a valid address",
  "Kein Bild": "not an image",
  "Zugriff auf {0} nicht erlaubt": "Access to {0} not allowed",
  "Bild wird geladen …": "Loading image …",
  "Bilder": "Images",
  "Vorschaubilder der Karten": "Card thumbnails",
  "Vorschaubild bei jedem Anime": "Thumbnail for every anime",
  "Vorschaubild nur bei hervorgehobenen (★)": "Thumbnail only for highlighted (★)",
  "Keine Vorschaubilder": "No thumbnails",
  "★ Favoriten": "★ Favorites",
  "Keine": "None",
  "Größe": "Size",
  "Größe der Vorschaubilder": "Thumbnail size",
  // Popup: Erweitert
  "Erweitert": "Advanced",
  "Knöpfe": "Buttons",
  "Hervorheben-Knopf": "Highlight button",
  "Ausblenden-Knopf": "Hide button",
  "Kommentare-Knopf (AniList)": "Comments button (AniList)",
  "Sprache und Staffel als Abzeichen": "Language and season as badges",
  "Titel aufräumen": "Tidy titles",
  "Datum": "Date",
  "Datum und Uhrzeit": "Date and time",
  // Sprachnamen (Zusätze in Klammern)
  "Deutsch": "German",
  "中文 (Chinesisch)": "中文 (Chinese)",
  "한국어 (Koreanisch)": "한국어 (Korean)",
  "日本語 (Japanisch)": "日本語 (Japanese)",
  // Kalenderkarten (content.js)
  "Hervorheben": "Highlight",
  "Ausblenden (ausgrauen, nach unten)": "Hide (grey out, move down)",
  "Kommentare zur Folge": "Episode comments",
  "Fortschritt {0} %": "Progress {0} %",
  "Sprachfassung": "Language version",
  "Auch verfügbar: {0}": "Also available: {0}",
  "ST": "S",
  "T": "P",
  "Staffel {0}": "Season {0}",
  ", Teil {0}": ", part {0}",
  // Kommentar-Panel (comments.js)
  "MyAnimeList-Abruf fehlgeschlagen. Bitte das Add-on mit ↻ neu laden.": "MyAnimeList request failed. Please reload the add-on with ↻.",
  "MyAnimeList meldet zu viele Anfragen. Bitte kurz warten und erneut öffnen.": "MyAnimeList reports too many requests. Please wait a moment and open again.",
  "MyAnimeList (Jikan) ist gerade überlastet oder nicht erreichbar (Fehler {0}).": "MyAnimeList (Jikan) is overloaded or unreachable right now (error {0}).",
  "MyAnimeList-Abruf fehlgeschlagen (Fehler {0}).": "MyAnimeList request failed (error {0}).",
  "MyAnimeList nicht erreichbar ({0}).": "MyAnimeList unreachable ({0}).",
  "keine Verbindung": "no connection",
  "Zeitüberschreitung": "timeout",
  "Folgen {0}–{1}": "Episodes {0}–{1}",
  "Folge {0}": "Episode {0}",
  "Diskussion": "Discussion",
  "Schließen (Esc)": "Close (Esc)",
  "Suche bei AniList …": "Searching AniList …",
  "AniList: nichts gefunden": "AniList: nothing found",
  "AniList klappt nicht, versuche MyAnimeList …": "AniList failed, trying MyAnimeList …",
  "MyAnimeList: nichts gefunden": "MyAnimeList: nothing found",
  "Keine Kommentar-Quelle erreichbar.": "No comment source reachable.",
  "Abruf fehlgeschlagen, bitte das Add-on mit ↻ neu laden": "Request failed, please reload the add-on with ↻",
  "Fehler in der Antwort": "error in the response",
  "zu viele Anfragen, bitte kurz warten": "too many requests, please wait a moment",
  "Fehler {0}": "error {0}",
  "Anime bei {0}": "Anime on {0}",
  "Lade Diskussionen …": "Loading discussions …",
  "Noch keine Kommentare.": "No comments yet.",
  "Auf AniList mitdiskutieren ↗": "Join the discussion on AniList ↗",
  "Überblick über die Staffel:": "Season overview:",
  "Durchschnittsbewertung": "Average score",
  "{0} Mitglieder auf AniList": "{0} members on AniList",
  "{0}/100 · Rezension von {1}": "{0}/100 · review by {1}",
  "Neueste Diskussionen:": "Latest discussions:",
  "Auf AniList ansehen ↗": "View on AniList ↗",
  "Keine Diskussion zu Folge {0}": "No discussion for episode {0}",
  ", neueste: Folge {0}": ", latest: episode {0}",
  "Folge der Karte unbekannt": "Episode of the card unknown",
  ", neueste Diskussion: Folge {0}": ", latest discussion: episode {0}",
  "Zu diesem Anime gibt es noch keine Folgen-Threads.": "There are no episode threads for this anime yet.",
  "Neueste Folgen-Threads (Nummerierung kann abweichen):": "Latest episode threads (numbering may differ):",
  "Auf MyAnimeList mitschreiben ↗": "Join the discussion on MyAnimeList ↗",
  "{0} Kommentare": "{0} comments",
  " · zuletzt {0}, {1}": " · last {0}, {1}",
  "[Spoiler: {0}]": "[Spoiler: {0}]",
  "[Bild]": "[Image]",
  // Vorschau und Bewertungen (theme.js), weitere Popup-Texte
  "Kalender hell/dunkel umschalten": "Toggle calendar light/dark",
  "Vorschau: {0}": "Preview: {0}",
  "Aktuell": "Current",
  "Nächste Staffel": "Next season",
  "Geschwindigkeit im Player": "Speed control in the player",
  "Player": "Player",
  "Heute": "Today",
  "Top 10 der Season": "Top 10 of the season",
  "AniList-Community": "AniList community",
  "Beste Bewertung": "Top rated",
  "Beliebteste": "Most popular",
  "Lädt …": "Loading …",
  "AniList nicht erreichbar ({0}).": "AniList not reachable ({0}).",
  "Für diese Season gibt es noch keine Liste.": "No list for this season yet.",
  "Im Kalender zeigen": "Show in calendar",
  "noch keine Note": "no score yet",
  "{0} Mitglieder": "{0} members",
  "★ Favorit": "★ Favorite",
  "im Kalender": "in calendar",
  "Zu heute springen": "Jump to today",
  "Wieder alle Anime zeigen": "Show all anime again",
  "Nur Favoriten (★) zeigen": "Show favorites (★) only",
  "Nur Favoriten (★) zeigen – noch keine markiert": "Show favorites (★) only – none marked yet",
  "Intro, Rückblick und Abspann automatisch überspringen": "Skip intro, recap and credits automatically",
  "Bildschirmfüllende Einblendungen (z. B. nach der letzten Folge) automatisch schließen": "Automatically close full-screen overlays (e.g. after the last episode)",
  "Zur Serie": "Go to series",
  "Abspielen": "Play",
  "Schließen": "Close",
  "📰 News ({0})": "📰 News ({0})",
  "Quelle: ": "Source: ",
  "Start": "Start",
  "ungefährer Start": "approx. start",
  "{0} Bewertungen": "{0} ratings",
  "{0} Mio.": "{0}M",
  "{0} Tsd.": "{0}K",
  "wird geladen …": "loading …",
  "noch keine Bewertung": "no rating yet",
  "keine Daten": "no data",
  "bestbewertet": "top rated",
  "beliebteste": "most popular",
  "Frühling": "Spring",
  "Sommer": "Summer",
  "Herbst": "Fall",
  // Seite „Fehler melden“ (report.html)
  "Fehler melden": "Report a problem",
  "Beschreibe kurz, was nicht stimmt. Daraus wird eine E-Mail in deinem Mailprogramm, die du vor dem Senden noch prüfen kannst.":
    "Briefly describe what is wrong. This becomes an email in your mail app that you can check before sending.",
  "Was ist passiert?": "What happened?",
  "z. B. Bei „Café Kitsune“ fehlt das Poster, nachdem ich die Sprache auf Englisch gestellt habe.":
    "e.g. The poster for “Café Kitsune” is missing after I switched the language to English.",
  "Technische Infos anhängen (Version, Browser, Einstellungen, Aufbau einer Kalenderkarte; keine Kontodaten)":
    "Attach technical info (version, browser, settings, structure of one calendar card; no account data)",
  "Technische Infos ansehen": "View technical info",
  "E-Mail erstellen": "Create email",
  "Text kopieren": "Copy text",
  "Text kopiert.": "Text copied.",
  "Bis zu 7 Meldungen pro Woche sind möglich.": "Up to 7 reports per week are possible.",
  "Fehlermeldung": "problem report",
  "Bitte beschreibe den Fehler in ein paar Worten (mindestens 20 Zeichen).": "Please describe the problem in a few words (at least 20 characters).",
  "Links zu anderen Seiten sind in Meldungen nicht erlaubt.": "Links to other websites are not allowed in reports.",
  "Bitte keine E-Mail-Adressen oder Telefonnummern in die Meldung schreiben.": "Please do not put email addresses or phone numbers in the report.",
  "Die Meldung sieht nach Zeichensalat aus. Bitte beschreibe den Fehler in normalen Sätzen.": "The report looks like gibberish. Please describe the problem in normal sentences.",
  "Bitte nicht alles in Großbuchstaben schreiben.": "Please do not write everything in capital letters.",
  "Diese Meldung hast du schon einmal geschickt.": "You have already sent this report.",
  "Bitte warte nach einer Meldung 10 Minuten bis zur nächsten.": "Please wait 10 minutes after a report before sending the next one.",
  "Du hast diese Woche schon {0} Fehler gemeldet. Die nächste Meldung ist ab {1} möglich.": "You have already sent {0} reports this week. The next report is possible from {1}.",
  "Meldungen per E-Mail sind noch nicht eingerichtet. Kopiere den Text und schick ihn dem Entwickler.": "Email reports are not set up yet. Copy the text and send it to the developer.",
  "Die E-Mail wurde in deinem Mailprogramm vorbereitet. Öffnet sich nichts, ist der Text kopiert: Schick ihn an {0}.": "The email has been prepared in your mail app. If nothing opens, the text is copied: send it to {0}."
};

// Text in der gewählten Sprache; T("Folge {0}", 5) -> "Folge 5" bzw. "Episode 5"
function T(de, ...args) {
  let s = crlfLang === "en" && Object.prototype.hasOwnProperty.call(CRLF_EN, de) ? CRLF_EN[de] : de;
  if (args.length) s = s.replace(/\{(\d+)\}/g, (m, i) => (args[+i] !== undefined ? String(args[+i]) : m));
  return s;
}

// Zahlen und Datumsangaben passend zur Sprache
function crlfLocale() { return crlfLang === "en" ? "en-US" : "de-DE"; }

// gespeicherte Sprache laden; crlfLangReady ist erfüllt, sobald crlfLang feststeht (das Popup wartet darauf)
var crlfLangReady = new Promise((ok) => {
  try {
    chrome.storage.sync.get({ uiLang: "de" }, (s) => {
      crlfLang = s && s.uiLang === "en" ? "en" : "de";
      ok(crlfLang);
    });
  } catch (e) { ok(crlfLang); }
});

// Staffel-Abzeichen „ST 1 | T 2“ (englisch „S 1 | P 2“) ohne innerHTML aufbauen
function crlfSeasonBadge(el, n, part) {
  const small = (t) => { const e = document.createElement("small"); e.textContent = t; return e; };
  el.replaceChildren(small(T("ST")), String(n));
  if (part) { const sep = document.createElement("i"); sep.className = "crlf-sep"; el.append(sep, small(T("T")), String(part)); }
}
