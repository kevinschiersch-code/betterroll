// report.js – Seite „Fehler melden“. Nimmt eine kurze Beschreibung und (auf Wunsch) technische Infos und erstellt
// daraus eine E-Mail im Mailprogramm des Nutzers (mailto:). Gesendet wird nur, was der Nutzer dort selbst abschickt;
// das Add-on überträgt nichts. Höchstens 7 Meldungen in 7 Tagen und 10 Minuten Abstand je Browser
// (storage.local „crReportTimes“), dazu der Spamschutz unten.
// Die technischen Infos sammelt das Popup beim Klick auf „Fehler melden“ (storage.local „crReportDraft“).

const REPORT_TO = ""; // Empfängeradresse der Meldungen; leer = nur „Text kopieren“
const MAIL_MAX = 1200; // längere mailto:-Adressen schneiden manche Mailprogramme ab

const $ = (id) => document.getElementById(id);
const LIMIT = 7, WEEK = 7 * 24 * 3600 * 1000; // höchstens 7 Meldungen in 7 Tagen (gleitend)
const GAP = 10 * 60 * 1000; // mindestens 10 Minuten zwischen zwei Meldungen

// ===== Spamschutz =====
// Prüft die Beschreibung, bevor eine E-Mail entsteht. Gibt den Grund (deutscher Text für T) zurück oder "" wenn ok.
// Regeln: 20–1500 Zeichen, mindestens 4 Wörter, keine Links außer zu crunchyroll.com/anilist.co/myanimelist.net,
// keine E-Mail-Adressen oder Telefonnummern, kein Zeichensalat (Wiederholungen, kaum verschiedene Buchstaben),
// kein Dauer-Großschreiben, nicht derselbe Text wie eine frühere Meldung.
const OK_HOSTS = /^(?:www\.)?(?:crunchyroll\.com|anilist\.co|myanimelist\.net)$/i;
// Text vereinfacht (klein, nur Buchstaben/Ziffern) für Vergleiche
function normText(t) { return t.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim(); }
// kurzer Fingerabdruck eines Texts (gegen doppelte Meldungen)
function textHash(t) { let h = 2166136261; for (const c of normText(t)) h = Math.imul(h ^ c.codePointAt(0), 16777619) >>> 0; return h.toString(36); }
// Grund, warum der Text nicht gesendet werden kann (Spamschutz), oder ""
function spamReason(text, sentHashes) {
  const t = text.trim();
  if (t.length < 20) return "Bitte beschreibe den Fehler in ein paar Worten (mindestens 20 Zeichen).";
  const words = normText(t).split(" ").filter((w) => w.length > 1);
  if (words.length < 4) return "Bitte beschreibe den Fehler in ein paar Worten (mindestens 20 Zeichen).";
  for (const m of t.matchAll(/(?:https?:\/\/|www\.)([^\s/]+)/gi)) if (!OK_HOSTS.test(m[1])) return "Links zu anderen Seiten sind in Meldungen nicht erlaubt.";
  if (/[\w.+-]+@[\w-]+\.[\w.]+/.test(t) || /(?:\+|00)\d[\d\s/-]{7,}\d/.test(t)) return "Bitte keine E-Mail-Adressen oder Telefonnummern in die Meldung schreiben.";
  if (/(.)\1{7,}/u.test(t) || /(\S{2,6})\1{4,}/u.test(t.replace(/\s+/g, ""))) return "Die Meldung sieht nach Zeichensalat aus. Bitte beschreibe den Fehler in normalen Sätzen.";
  const letters = t.replace(/[^\p{L}]/gu, "");
  if (letters.length >= 20 && new Set(letters.toLowerCase()).size < 6) return "Die Meldung sieht nach Zeichensalat aus. Bitte beschreibe den Fehler in normalen Sätzen.";
  if (new Set(words).size / words.length < 0.35 && words.length >= 8) return "Die Meldung sieht nach Zeichensalat aus. Bitte beschreibe den Fehler in normalen Sätzen.";
  const caps = letters.replace(/[^\p{Lu}]/gu, "").length;
  if (letters.length >= 30 && caps / letters.length > 0.7) return "Bitte nicht alles in Großbuchstaben schreiben.";
  if (sentHashes.includes(textHash(t))) return "Diese Meldung hast du schon einmal geschickt.";
  return "";
}
// zufällige Kennung dieser Installation (keine persönlichen Daten): hilft beim Aussortieren, falls jemand Meldungen missbraucht
async function installId() {
  let { crInstallId } = await chrome.storage.local.get("crInstallId");
  if (!crInstallId) { crInstallId = [...crypto.getRandomValues(new Uint8Array(6))].map((b) => b.toString(16).padStart(2, "0")).join(""); await chrome.storage.local.set({ crInstallId }); }
  return crInstallId;
}
let diagText = "";

// feste Texte der Seite übersetzen
function applyI18n() {
  document.documentElement.lang = crlfLang;
  document.title = `BetterRoll – ${T("Fehler melden")}`;
  for (const e of document.querySelectorAll("[data-i18n]")) {
    if (!e.dataset.i18n) e.dataset.i18n = e.textContent;
    e.textContent = T(e.dataset.i18n);
  }
  const ta = $("what");
  if (!ta.dataset.ph) ta.dataset.ph = ta.placeholder;
  ta.placeholder = T(ta.dataset.ph);
}

// Kopf der Meldung: Version, Browser, Sprache, wichtigste Einstellungen (keine Konto- oder Anmeldedaten)
async function buildInfo() {
  const s = await chrome.storage.sync.get(CR_DEFAULT_SETTINGS);
  const keep = ["active", "enabled", "language", "prefer", "merge", "thumbs", "posterSize", "pageTheme", "pageBg", "dateFormat", "hideTop", "uiLang", "autoClose", "speedCtl", "autoSkip", "featureRank"];
  const set = keep.filter((k) => k in s).map((k) => `${k}=${s[k]}`).join(", ");
  const { crReportDraft: d, crClosedOverlays: closed = [], crOverlaySeen: kept, crSkipLog: skips = [], crPlayerDiag: player } = await chrome.storage.local.get(["crReportDraft", "crClosedOverlays", "crOverlaySeen", "crSkipLog", "crPlayerDiag"]);
  // zuletzt automatisch geschlossene Einblendungen (overlay.js): Seite, Klassen, Textanfang
  const shut = closed.map((c) => `${new Date(c.t).toISOString().slice(0, 16)} ${c.page} [${c.cls}] ${c.text}`).join("\n");
  return [
    `BetterRoll ${chrome.runtime.getManifest().version}`,
    `Browser: ${navigator.userAgent}`,
    `Einstellungen: ${set}`,
    d && d.diag ? `--- Kalender ---\n${d.diag}` : "--- Kalender: nicht geöffnet ---",
    shut ? `--- Geschlossene Einblendungen ---\n${shut}` : "",
    skips.length ? `--- Übersprungen ---\n${skips.map((x) => `${new Date(x.t).toISOString().slice(0, 16)} ${x.what}`).join("\n")}` : "",
    player ? `--- Player-Menü (${new Date(player.t).toISOString().slice(0, 16)}, ${player.host}) ---\n${player.text}` : "",
    kept ? `--- Offen gelassen (${kept.reason}) ---\n${new Date(kept.t).toISOString().slice(0, 16)} ${kept.page} [${kept.cls}] ${kept.text} · Knöpfe: ${kept.btns}` : ""
  ].filter(Boolean).join("\n");
}

// Text der Meldung: Beschreibung und (falls angehakt) technische Infos; full = ungekürzt
function reportText(full) {
  const what = $("what").value.trim();
  const parts = [what];
  if ($("withDiag").checked) parts.push("", "-----", full ? diagText : diagText.slice(0, Math.max(0, MAIL_MAX - what.length - 60)) + (diagText.length > MAIL_MAX - what.length - 60 ? "\n[…gekürzt]" : ""));
  return parts.join("\n");
}

// Meldung unter dem Formular
function say(text, warn) {
  $("msg").textContent = text;
  $("msg").classList.toggle("warn", !!warn);
}

// Zeitpunkte der Meldungen der letzten 7 Tage
async function recentReports() {
  const { crReportTimes = [] } = await chrome.storage.local.get("crReportTimes");
  return crReportTimes.filter((t) => Date.now() - t < WEEK);
}
// Grenze erreicht (7 pro Woche oder weniger als 10 Min. seit der letzten)?
async function limitReached() {
  const recent = await recentReports();
  return recent.length >= LIMIT || (recent.length && Date.now() - Math.max(...recent) < GAP);
}
// Senden-Knopf und Hinweis an die Grenzen anpassen
async function syncLimit() {
  const done = await limitReached();
  $("send").disabled = done || !REPORT_TO;
  const recent = await recentReports();
  if (done && recent.length < LIMIT) {
    say(T("Bitte warte nach einer Meldung 10 Minuten bis zur nächsten."), true);
    setTimeout(syncLimit, GAP - (Date.now() - Math.max(...recent)) + 1000);
  } else if (done) {
    const next = new Date(Math.min(...recent) + WEEK);
    say(T("Du hast diese Woche schon {0} Fehler gemeldet. Die nächste Meldung ist ab {1} möglich.", LIMIT, next.toLocaleDateString(crlfLocale(), { weekday: "long", day: "numeric", month: "long" })), true);
  }
  else if (!REPORT_TO) say(T("Meldungen per E-Mail sind noch nicht eingerichtet. Kopiere den Text und schick ihn dem Entwickler."), true);
  else say(""); // Wartezeit vorbei: Hinweis entfernen
}

// ganzen Text in die Zwischenablage (Ersatzweg über ein Textfeld)
async function copyText() {
  const text = reportText(true);
  try { await navigator.clipboard.writeText(text); return true; } catch (e) {
    const ta = document.createElement("textarea");
    ta.value = text; document.body.append(ta); ta.select();
    let ok = false;
    try { ok = document.execCommand("copy"); } catch (e2) {}
    ta.remove();
    return ok;
  }
}

$("what").addEventListener("input", () => { $("whatCount").textContent = $("what").value.length; });
$("withDiag").addEventListener("change", () => { $("diagBox").hidden = !$("withDiag").checked; });
$("copy").addEventListener("click", async () => {
  const why = spamReason($("what").value, []);
  if (why) return say(T(why), true);
  say((await copyText()) ? T("Text kopiert.") : T("Kopieren nicht möglich"), false);
});
$("form").addEventListener("submit", async (e) => {
  e.preventDefault();
  if (await limitReached()) return syncLimit();
  if (!REPORT_TO) return syncLimit();
  const { crReportHashes = [] } = await chrome.storage.local.get("crReportHashes");
  const why = spamReason($("what").value, crReportHashes);
  if (why) return say(T(why), true);
  await chrome.storage.local.set({ crReportTimes: [...(await recentReports()), Date.now()], crReportHashes: [...crReportHashes, textHash($("what").value)].slice(-30) });
  await chrome.storage.local.remove("crReportDraft");
  await copyText(); // vollständiger Text als Rückfall, falls das Mailprogramm die Mail kürzt oder sich nicht öffnet
  // fester Betreff-Anfang „[BetterRoll]“ und Kennung der Installation: so lassen sich Meldungen im Postfach filtern
  const subject = `[BetterRoll] ${chrome.runtime.getManifest().version} ${T("Fehlermeldung")} #${await installId()}`;
  location.href = `mailto:${REPORT_TO}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(reportText(false))}`;
  $("send").disabled = true;
  say(T("Die E-Mail wurde in deinem Mailprogramm vorbereitet. Öffnet sich nichts, ist der Text kopiert: Schick ihn an {0}.", REPORT_TO), false);
});

crlfLangReady.then(async () => {
  applyI18n();
  diagText = await buildInfo();
  $("diag").textContent = diagText;
  syncLimit();
});
