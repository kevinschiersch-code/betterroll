// skip.js – Intro, Rückblick und Abspann automatisch überspringen (Nutzerwunsch). Läuft wie speed.js in allen Rahmen
// der Crunchyroll-Seiten (Player-iframe). Nutzt nur den eigenen „… überspringen“-Knopf des Players: Taucht er auf,
// wird er einmal angeklickt. Keine Schnittstelle, kein Netzverkehr. Schalter: Einstellung autoSkip (ab Werk an).
// Die letzten Sprünge stehen in storage.local „crSkipLog“ (für „Fehler melden“).
(() => {
  const WHAT = /intro|opening|vorspann|recap|rückblick|zusammenfassung|credits|abspann|outro|ending/i;
  const VERB = /skip|überspring/i;
  const done = new WeakSet(); // schon geklickte Knöpfe (wieder frei, sobald sie verschwinden: Player nutzt evtl. einen Knopf für Intro und Abspann)
  let on = true, timer = 0;

  // Schalter lesen (Hauptschalter und autoSkip)
  const load = () => chrome.storage.sync.get({ active: true, autoSkip: true }, (s) => { on = s.active && s.autoSkip; arm(); });
  load();
  chrome.storage.onChanged.addListener((c, area) => { if (area === "sync" && (c.active || c.autoSkip)) load(); });

  // Prüfung alle 0,7 s, aber nur solange in diesem Rahmen ein Video läuft (der Knopf erscheint oft nur per Klassenwechsel)
  function arm() {
    clearInterval(timer);
    if (on) timer = setInterval(check, 700);
  }

  // Beschriftung eines Knopfs (aria-label, title, Text)
  const label = (el) => [el.getAttribute("aria-label"), el.getAttribute("title"), el.textContent].filter(Boolean).join(" ").replace(/\s+/g, " ").trim();
  // sichtbar und groß genug?
  const visible = (el) => {
    const r = el.getBoundingClientRect();
    if (r.width < 20 || r.height < 12) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== "hidden" && cs.display !== "none" && +cs.opacity > 0.05;
  };

  // Überspringen-Knopf suchen und einmal klicken (nur während das Video läuft)
  function check() {
    const video = document.querySelector("video");
    if (!video || video.paused || video.ended) return;
    const list = document.querySelectorAll('[data-testid*="skip" i], button, [role="button"]');
    for (const el of list) {
      if (done.has(el)) { if (!visible(el)) done.delete(el); continue; }
      if (el.closest("[data-crlf-speed]")) continue;
      const text = label(el);
      if (text.length > 60) continue; // ganze Leisten/Menüs, nicht ein Knopf
      const testid = (el.getAttribute("data-testid") || "").toLowerCase();
      if (!(testid.includes("skip") || (VERB.test(text) && WHAT.test(text)))) continue;
      if (!visible(el)) continue;
      done.add(el);
      press(el);
      log(text || testid);
      return;
    }
  }

  // Klick auslösen. Der Treffer kann ein SVG o. Ä. ohne .click() sein (data-testid am Symbol): dann den umgebenden
  // Knopf nehmen bzw. die Mausereignisse selbst schicken, wie ein echter Klick sie liefert
  function press(el) {
    const btn = el.closest("button, [role=button], a") || el;
    if (typeof btn.click === "function") { btn.click(); return; }
    const r = btn.getBoundingClientRect(), at = { bubbles: true, cancelable: true, composed: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    for (const t of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) btn.dispatchEvent(new (t.startsWith("pointer") ? PointerEvent : MouseEvent)(t, at));
  }

  // Sprung für „Fehler melden“ merken (die letzten 5)
  function log(what) {
    chrome.storage.local.get({ crSkipLog: [] }, ({ crSkipLog }) => {
      crSkipLog.unshift({ t: Date.now(), what: what.slice(0, 40) });
      chrome.storage.local.set({ crSkipLog: crSkipLog.slice(0, 5) });
    });
  }
})();
