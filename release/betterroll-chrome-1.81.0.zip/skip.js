// skip.js – Intro, Rückblick und Abspann automatisch überspringen (Nutzerwunsch). Läuft wie speed.js in allen Rahmen
// der Crunchyroll-Seiten (Player-iframe). Nutzt nur den eigenen „… überspringen“-Knopf des Players: Taucht er auf,
// wartet skip.js 2 s und klickt ihn dann einmal; danach geht es 1,5 s zurück, damit man nicht mitten in die Szene
// springt (statt 90 s also 86,5 s). Pause, Spulen oder ein verschwundener Knopf brechen das Warten ab.
// Keine Schnittstelle, kein Netzverkehr. Schalter: Einstellung autoSkip (ab Werk an).
// Die letzten Sprünge stehen in storage.local „crSkipLog“ (für „Fehler melden“).
(() => {
  const WHAT = /intro|opening|vorspann|recap|rückblick|zusammenfassung|credits|abspann|outro|ending/i;
  const VERB = /skip|überspring/i;
  const done = new WeakSet(); // schon geklickte Knöpfe (wieder frei, sobald sie verschwinden: Player nutzt evtl. einen Knopf für Intro und Abspann)
  const WAIT_MS = 2000, BACK_S = 1.5;
  let on = true, timer = 0;
  let pending = null; // { el, video, at, seeked } – Knopf, der gerade seine 2 s abwartet

  // Schalter lesen (Hauptschalter und autoSkip)
  const load = () => chrome.storage.sync.get({ active: true, autoSkip: true }, (s) => { on = s.active && s.autoSkip; arm(); });
  load();
  chrome.storage.onChanged.addListener((c, area) => { if (area === "sync" && (c.active || c.autoSkip)) load(); });

  // Prüfung alle 0,25 s (genau genug für die 2 s Wartezeit), aber nur solange in diesem Rahmen ein Video läuft (der Knopf erscheint oft nur per Klassenwechsel)
  function arm() {
    clearInterval(timer);
    pending = null;
    if (on) timer = setInterval(check, 250);
  }

  // Beschriftung eines Knopfs (aria-label, title, Text)
  const label = (el) => [el.getAttribute("aria-label"), el.getAttribute("title"), el.textContent].filter(Boolean).join(" ").replace(/\s+/g, " ").trim();
  // sichtbar und groß genug?
  const visible = (el) => {
    const r = el.getBoundingClientRect();
    if (r.width < 20 || r.height < 12) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== "hidden" && cs.display !== "none" && +cs.opacity > 0.05;
  };

  // Überspringen-Knopf suchen; gefunden -> 2 s warten (nur während das Video läuft), dann klicken
  function check() {
    const video = document.querySelector("video");
    if (pending) return wait(video);
    if (!video || video.paused || video.ended) return;
    const list = document.querySelectorAll('[data-testid*="skip" i], button, [role="button"]');
    for (const el of list) {
      if (done.has(el)) { if (!visible(el)) done.delete(el); continue; }
      if (el.closest("[data-crlf-speed]")) continue;
      const text = label(el);
      if (text.length > 60) continue; // ganze Leisten/Menüs, nicht ein Knopf
      const testid = (el.getAttribute("data-testid") || "").toLowerCase();
      if (!(testid.includes("skip") || (VERB.test(text) && WHAT.test(text)))) continue;
      if (!visible(el)) continue;
      done.add(el);
      pending = { el, video, at: Date.now(), what: text || testid, seeked: false };
      video.addEventListener("seeking", pending.onSeek = () => { if (pending) pending.seeked = true; });
      return;
    }
  }

  // Wartezeit: Abbruch bei Pause (Knopf darf danach neu warten), Spulen (Nutzer hat selbst gesprungen) oder wenn der
  // Knopf verschwindet; nach 2 s klicken und 1,5 s vor das Ende des Abschnitts zurückgehen
  function wait(video) {
    const p = pending;
    const stop = (again) => { p.video.removeEventListener("seeking", p.onSeek); pending = null; if (again) done.delete(p.el); };
    if (p.seeked || !p.el.isConnected || !visible(p.el) || video !== p.video) return stop(false);
    if (p.video.paused || p.video.ended) return stop(true);
    if (Date.now() - p.at < WAIT_MS) return;
    stop(false);
    const from = p.video.currentTime, at = Date.now();
    p.video.addEventListener("seeked", () => { if (Date.now() - at < 4000) back(p.video, from); }, { once: true });
    press(p.el);
    log(p.what);
  }

  // nach dem Sprung des Players 1,5 s zurück (nur bei einem echten Sprung nach vorn, nicht bei einer neuen Folge)
  function back(video, from) {
    const to = video.currentTime;
    if (to - from > BACK_S + 1) video.currentTime = Math.max(from, to - BACK_S);
  }

  // Klick auslösen. Der Treffer kann ein SVG o. Ä. ohne .click() sein (data-testid am Symbol): dann den umgebenden
  // Knopf nehmen bzw. die Mausereignisse selbst schicken, wie ein echter Klick sie liefert
  function press(el) {
    const btn = el.closest("button, [role=button], a") || el;
    if (typeof btn.click === "function") { btn.click(); return; }
    const r = btn.getBoundingClientRect(), at = { bubbles: true, cancelable: true, composed: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    for (const t of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) btn.dispatchEvent(new (t.startsWith("pointer") ? PointerEvent : MouseEvent)(t, at));
  }

  // Sprung für „Fehler melden“ merken (die letzten 5)
  function log(what) {
    chrome.storage.local.get({ crSkipLog: [] }, ({ crSkipLog }) => {
      crSkipLog.unshift({ t: Date.now(), what: what.slice(0, 40) });
      chrome.storage.local.set({ crSkipLog: crSkipLog.slice(0, 5) });
    });
  }
})();
