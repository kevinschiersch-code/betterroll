// overlay.js – läuft auf allen Crunchyroll-Seiten. Schließt bildschirmfüllende Einblendungen, die von selbst
// erscheinen (z. B. nach der letzten Folge), indem es ihren eigenen ✕-Knopf drückt (Nutzerwunsch; Popup → Erweitert →
// „Player“ ✕, Einstellung autoClose, ab Werk an). Vorsichtig, damit nichts Wichtiges zugeht:
//   - nur Ebenen, die den größten Teil des Fensters bedecken (fest stehend, über der Seite) und einen
//     Schließen-Knopf oben rechts haben
//   - nie mit Videoplayer, Eingabefeldern (Anmeldung, Suche) oder Cookie-Abfrage
//   - nie, wenn man kurz vorher selbst geklickt/getippt hat (dann hat man sie vermutlich selbst geöffnet, z. B. das Menü)
//   - je Ebene nur ein Versuch (geht sie davon nicht zu, bleibt sie offen)
// Gesucht wird nur an einigen Punkten des Fensters (elementFromPoint und Vorfahren), nicht im ganzen Dokument.
(() => {
  let on = true, userAt = 0, timer = 0;
  const tried = new WeakSet(); // Ebenen, die schon einmal geschlossen werden sollten
  const CLOSE_RE = /^(close|schlie(ß|ss)en|dismiss|×|✕|✖|x)$|close|schlie(ß|ss)en|dismiss/i;
  chrome.storage.sync.get({ active: true, autoClose: true }, (s) => { on = s.active && s.autoClose; check(); });
  chrome.storage.onChanged.addListener((c, area) => {
    if (area !== "sync" || !(c.active || c.autoClose)) return;
    chrome.storage.sync.get({ active: true, autoClose: true }, (s) => { on = s.active && s.autoClose; });
  });
  for (const t of ["pointerdown", "keydown", "touchstart"]) addEventListener(t, () => { userAt = Date.now(); }, { capture: true, passive: true });

  // Schließen-Knopf der Ebene: Beschriftung/Titel nach „Schließen“, oder ein Kreuz, und er sitzt im oberen rechten Viertel
  function closeButton(layer, r) {
    for (const b of layer.querySelectorAll('button, [role="button"], a[href="#"], [aria-label]')) {
      const label = [b.getAttribute("aria-label"), b.getAttribute("title"), b.dataset && b.dataset.t, b.textContent].filter(Boolean).join(" ").trim();
      if (!label || label.length > 40 || !CLOSE_RE.test(label)) continue;
      const br = b.getBoundingClientRect();
      if (!br.width || !br.height) continue;
      if (br.left + br.width / 2 < r.left + r.width / 2 || br.top + br.height / 2 > r.top + r.height / 2) continue;
      return b;
    }
    return null;
  }

  // fest stehende Ebenen unter der Fenstermitte und vier weiteren Punkten (jeweils das Element und seine Vorfahren)
  function candidates(vw, vh) {
    const out = new Set();
    for (const [fx, fy] of [[0.5, 0.5], [0.3, 0.3], [0.7, 0.3], [0.3, 0.7], [0.7, 0.7]]) {
      for (let el = document.elementFromPoint(vw * fx, vh * fy); el && el !== document.body && el !== document.documentElement; el = el.parentElement) out.add(el);
    }
    return out;
  }

  // große Einblendung gefunden? Dann ihren ✕-Knopf drücken (je Ebene höchstens einmal)
  function check() {
    if (!on || !document.body || document.fullscreenElement) return;
    if (Date.now() - userAt < 1500) return; // selbst geöffnet
    const vw = innerWidth, vh = innerHeight;
    for (const el of candidates(vw, vh)) {
      if (tried.has(el) || el.closest('[class*="crlf-"], #crlf-theme-toggle, #crlf-tools')) continue;
      const cs = getComputedStyle(el);
      if (cs.position !== "fixed" || cs.display === "none" || cs.visibility === "hidden" || parseFloat(cs.opacity) < 0.1) continue;
      const r = el.getBoundingClientRect();
      if (r.width < vw * 0.6 || r.height < vh * 0.6) continue;
      if (el.querySelector('video, iframe, input:not([type="checkbox"]):not([type="radio"]):not([type="hidden"]), textarea, select')) continue;
      const id = `${el.id} ${el.className && el.className.baseVal !== undefined ? el.className.baseVal : el.className}`;
      if (/onetrust|consent|cookie|login|signin|sign-in|auth|search|player/i.test(id)) continue;
      const btn = closeButton(el, r);
      if (!btn) continue;
      tried.add(el);
      el.style.setProperty("visibility", "hidden", "important"); // nicht erst aufblitzen lassen
      btn.click();
      setTimeout(() => { if (el.isConnected) el.style.removeProperty("visibility"); }, 1500); // ging nicht zu: wieder zeigen
      return;
    }
  }

  new MutationObserver(() => { clearTimeout(timer); timer = setTimeout(check, 60); })
    .observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["class", "style", "hidden", "open"] });
})();
